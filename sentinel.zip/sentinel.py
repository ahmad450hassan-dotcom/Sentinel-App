
import cv2
import os
import time
from datetime import datetime
import json

print("=== PROJECT SENTINEL - FINAL VERSION ===")

# Folders
os.makedirs("known_faces", exist_ok=True)
os.makedirs("thief_images", exist_ok=True)

# Languages
try:
    with open("languages.json", "r", encoding="utf-8") as f:
        LANGUAGES = json.load(f)
    print(f"Languages Loaded: {LANGUAGES}")
except:
    print("languages.json not found")

current_lang = "ur" 
def get_text(key):
    msgs = {
        "en": {"owner": "Welcome Owner", "thief": "ALERT! Unknown Person!"},
        "ur": {"owner": "Khush Amdeed Malik", "thief": "Khabardar! Anjaan Shakhs!"},
        "ps": {"owner": "Kharaghlas Malak", "thief": "Khabardar! Na Pejandala Kas!"}
    }
    return msgs.get(current_lang, msgs["en"]).get(key, key)

# Camera
face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
cap = cv2.VideoCapture(0)

if not cap.isOpened():
    print("ERROR: Camera nahi khula! Laptop ka camera check karo")
    exit()

print(f"\n[SYSTEM] {get_text('owner')} - Security Active!")
print("[SYSTEM] Camera ON. 'q' dabao band karne ke liye")

known_face_exists = len(os.listdir("known_faces")) > 0
last_save_time = 0

while True:
    ret, frame = cap.read()
    if not ret:
        break

    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.1, 5)

    for (x, y, w, h) in faces:
        if known_face_exists:
            label = get_text("owner")
            color = (0, 255, 0)  # Green
        else:
            label = get_text("thief")
            color = (0, 0, 255)  # Red
            if time.time() - last_save_time > 5:
                filename = f"thief_images/thief_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
                cv2.imwrite(filename, frame)
                with open("security_log.txt", "a") as log:
                    log.write(f"{datetime.now()} - {label} - {filename}\n")
                print(f"[!] Saved: {filename}")
                last_save_time = time.time()

        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        cv2.putText(frame, label, (x, y-10), cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)

    cv2.imshow("PROJECT SENTINEL - Security Active", frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()
print("System Band Ho Gaya.")